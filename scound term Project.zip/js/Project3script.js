  // Create header element and set class
  const header = document.createElement('header');
  header.className = 'header';
  // Create nav-section section
  const navSection = document.createElement('section');
  navSection.className = 'nav-section';
  // Array of link objects with href and text
  const links = [
    { href: '#section1', text: 'Point 1' },
    { href: '#section2', text: 'Point 2' },
    { href: '#section3', text: 'Point 3' },
    { href: '#section4', text: 'Point 4' },
    { href: '#section5', text: 'Point 5' },
    { href: '#section6', text: 'Point 6' },
    { href: '#section7', text: 'Point 7' },
    { href: '#section8', text: 'Point 8' },
    { href: '#section9', text: 'Point 9' },
    { href: '#section10', text: 'Types of cybersecurity' },
    { href: '#Source', text: 'Sources' },
    { href: '#about', text: 'About' },
    { href: '#comments', text: 'Comment' },
  ];
  // Create anchor elements from links array and append
  links.forEach(link => {const a = document.createElement('a');
    a.href = link.href;
    a.textContent = link.text;
    navSection.appendChild(a);
  });
  // Append navSection to header
  header.appendChild(navSection);
  // Append header to body
  document.body.prepend(header);



document.querySelectorAll('.nav-section a').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const targetId = this.getAttribute('href');
    const targetElement = document.querySelector(targetId);
    if (targetElement) {
      const elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - 85;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  });
});

function showDetails(myname) {  
    console.log("Name passed to the function: " + myname);  
  
    const writerPostElement = document.getElementById("writer-post");  
  
    const writerInfo = writerPostElement.getAttribute("data-writer");  
  
    console.log("Writer Info: " + writerInfo);  
  

    alert("Name: " + myname + "\nWriter Info: " + writerInfo);  
}  
  
 
document.getElementById("writer-post").onclick = function () {  
    showDetails("Abd ELrahman Mahmoud Abdelrahman ahmad");  
};  

document.addEventListener("DOMContentLoaded", function() {
    const commentForm = document.getElementById("commentForm");
    const commentList = document.createElement("div");
    commentList.id = "commentList";
    document.getElementById("comments").appendChild(commentList);

    const commentCount = document.createElement("p");
    commentCount.id = "commentCount";
    commentCount.textContent = "Number of comments: 0";
    document.getElementById("comments").insertBefore(commentCount, commentList);

    let comments = [];

    commentForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const comment = document.getElementById("comment").value;

        const commentItem = document.createElement("div");
        commentItem.classList.add("commentItem");

        const nameElement = document.createElement("div");
        nameElement.classList.add("commentName");
        nameElement.textContent = "Name: " + name;

        const emailElement = document.createElement("div");
        emailElement.classList.add("commentEmail");
        emailElement.textContent = "Email: " + email;

        const commentTextElement = document.createElement("div");
        commentTextElement.classList.add("commentText");
        commentTextElement.textContent = "Comment: " + comment;

        // Append the elements to the comment item
        commentItem.appendChild(nameElement);
        commentItem.appendChild(emailElement);
        commentItem.appendChild(commentTextElement);

        // Append the comment item to the comment list
        commentList.appendChild(commentItem);

        // Add the new comment to the comments array
        comments.push({ name, email, comment });

        // Update the comment count
        commentCount.textContent = "Number of comments: " + comments.length;

        // Clear the form fields
        commentForm.reset();
    });
});

const scrollToTopBtn = document.getElementById("scrollToTopBtn");

window.onscroll = function() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        scrollToTopBtn.style.display = "block";
    } else {
        scrollToTopBtn.style.display = "none";
    }
};

scrollToTopBtn.onclick = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};
function showDetails(Dataabbreviations) {
  let DataabbreviationsType = Dataabbreviations.getAttribute("data-type");
  alert("The " + Dataabbreviations.innerHTML + " is a " + DataabbreviationsType + ".");
}