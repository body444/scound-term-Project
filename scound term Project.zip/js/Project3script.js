// Smooth scrolling for navigation links
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default anchor behavior
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Wait for the DOM to fully load
document.addEventListener("DOMContentLoaded", function() {
    const commentForm = document.getElementById("commentForm");
    const commentList = document.createElement("div");
    commentList.id = "commentList";
    document.getElementById("comments").appendChild(commentList);

    // Create a paragraph to display the number of comments
    const commentCount = document.createElement("p");
    commentCount.id = "commentCount";
    commentCount.textContent = "Number of comments: 0";
    document.getElementById("comments").insertBefore(commentCount, commentList);

    let comments = []; // Array to store comments

    // Event listener for form submission
    commentForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Get the values from the form
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const comment = document.getElementById("comment").value;

        // Create a new comment item
        const commentItem = document.createElement("div");
        commentItem.classList.add("commentItem");

        // Create and append the name, email, and comment elements
        const nameElement = document.createElement("div");
        nameElement.classList.add("commentName");
        nameElement.textContent = "Name: " + name;

        const emailElement = document.createElement("div");
        emailElement.classList.add("commentEmail");
        emailElement.textContent = "Email: " + email;

        const commentTextElement = document.createElement("div");
        commentTextElement.classList.add("commentText");
        commentTextElement.textContent = "Comment: " + comment;

        // Append the elements to the comment item
        commentItem.appendChild(nameElement);
        commentItem.appendChild(emailElement);
        commentItem.appendChild(commentTextElement);

        // Append the comment item to the comment list
        commentList.appendChild(commentItem);

        // Add the new comment to the comments array
        comments.push({ name, email, comment });

        // Update the comment count
        commentCount.textContent = "Number of comments: " + comments.length;

        // Clear the form fields
        commentForm.reset();
    });
});
