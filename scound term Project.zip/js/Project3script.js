
document.querySelectorAll('nav a').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const targetId = this.getAttribute('href');
    const targetElement = document.querySelector(targetId);
    if (targetElement) {
      const elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - 80;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  });
});

document.addEventListener("DOMContentLoaded", function() {
    const commentForm = document.getElementById("commentForm");
    const commentList = document.createElement("div");
    commentList.id = "commentList";
    document.getElementById("comments").appendChild(commentList);

    const commentCount = document.createElement("p");
    commentCount.id = "commentCount";
    commentCount.textContent = "Number of comments: 0";
    document.getElementById("comments").insertBefore(commentCount, commentList);

    let comments = [];

    commentForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const comment = document.getElementById("comment").value;

        const commentItem = document.createElement("div");
        commentItem.classList.add("commentItem");

        const nameElement = document.createElement("div");
        nameElement.classList.add("commentName");
        nameElement.textContent = "Name: " + name;

        const emailElement = document.createElement("div");
        emailElement.classList.add("commentEmail");
        emailElement.textContent = "Email: " + email;

        const commentTextElement = document.createElement("div");
        commentTextElement.classList.add("commentText");
        commentTextElement.textContent = "Comment: " + comment;

        // Append the elements to the comment item
        commentItem.appendChild(nameElement);
        commentItem.appendChild(emailElement);
        commentItem.appendChild(commentTextElement);

        // Append the comment item to the comment list
        commentList.appendChild(commentItem);

        // Add the new comment to the comments array
        comments.push({ name, email, comment });

        // Update the comment count
        commentCount.textContent = "Number of comments: " + comments.length;

        // Clear the form fields
        commentForm.reset();
    });
});
