document.addEventListener("DOMContentLoaded", () => {
  const navbar = document.getElementById("navbar");
  const sections = document.querySelectorAll("section");
  const scrollToTop = document.getElementById("scrollToTop");

  // Build NavBar
  sections.forEach((section) => {
    const listItem = document.createElement("li");
    const link = document.createElement("a");
    link.href = `#${section.id}`;
    link.textContent = section.dataset.title;
    listItem.appendChild(link);
    navbar.appendChild(listItem);
  });

  // Smooth Scrolling
  navbar.addEventListener("click", (e) => {
    e.preventDefault(); // Prevent default anchor behavior
    if (e.target.tagName === "A") {
      const targetSection = document.querySelector(
        e.target.getAttribute("href")
      );
      targetSection.scrollIntoView({
        behavior: "smooth",
      });
    }
  });

  // Highlight Active Section
  window.addEventListener("scroll", () => {
    let activeSection = null;
    sections.forEach((section) => {
      const rect = section.getBoundingClientRect();
      if (rect.top >= 0 && rect.top < window.innerHeight / 2) {
        activeSection = section;
      }
      section.classList.remove("active");
    });
    if (activeSection) activeSection.classList.add("active");
  });

  // Handle Comment Form
  const commentForm = document.getElementById("commentForm");
  const commentsDisplay = document.getElementById("commentsDisplay");

  commentForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const comment = document.getElementById("comment").value.trim();

    if (!name || !email || !comment || !email.includes("@")) {
      alert("Please provide valid inputs.");
      return;
    }

    const commentElement = document.createElement("div");
    commentElement.innerHTML = `
      <p><strong>${name}</strong> (${email})</p>
      <p>${comment}</p>
    `;
    commentsDisplay.appendChild(commentElement);
    commentForm.reset();
  });
});
